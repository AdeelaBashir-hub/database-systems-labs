-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2026 at 04:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carrentaldb`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `RegisterRental` (IN `custID` INT, IN `vehID` INT, IN `startDate` DATE, IN `endDate` DATE)   BEGIN
    DECLARE days INT;
    DECLARE rate DECIMAL(10,2);
    DECLARE total DECIMAL(10,2);

    SELECT DATEDIFF(endDate, startDate) INTO days;
    SELECT DailyRate INTO rate FROM Vehicles WHERE VehicleID = vehID;

    SET total = days * rate;

    INSERT INTO Rentals(CustomerID, VehicleID, RentalDate, ReturnDate)
    VALUES (custID, vehID, startDate, endDate);

    INSERT INTO Payments(RentalID, Amount, PaymentDate)
    VALUES (LAST_INSERT_ID(), total, CURDATE());

    UPDATE Vehicles SET Status = 'Rented' WHERE VehicleID = vehID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustomerID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustomerID`, `Name`, `Phone`, `Email`) VALUES
(1, 'Ali Khan', '0300-1234567', 'ali@example.com'),
(2, 'Sara Ahmed', '0301-9876543', 'sara@example.com'),
(3, 'Bilal Hussain', '0302-5555555', 'bilal@example.com');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` int(11) NOT NULL,
  `RentalID` int(11) DEFAULT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `PaymentDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `RentalID`, `Amount`, `PaymentDate`) VALUES
(1, 1, 15000.00, '2026-09-04'),
(2, 2, 12000.00, '2026-09-07'),
(3, 3, 6000.00, '2026-09-20'),
(4, 4, 6000.00, '2026-09-21'),
(5, 5, 6000.00, '2026-09-21');

-- --------------------------------------------------------

--
-- Stand-in structure for view `rentalreport`
-- (See below for the actual view)
--
CREATE TABLE `rentalreport` (
`Name` varchar(100)
,`Phone` varchar(20)
,`VehicleNumber` varchar(20)
,`Model` varchar(50)
,`RentalDate` date
,`ReturnDate` date
,`Amount` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `RentalID` int(11) NOT NULL,
  `CustomerID` int(11) DEFAULT NULL,
  `VehicleID` int(11) DEFAULT NULL,
  `RentalDate` date NOT NULL,
  `ReturnDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`RentalID`, `CustomerID`, `VehicleID`, `RentalDate`, `ReturnDate`) VALUES
(1, 1, 1, '2026-09-01', '2026-09-12'),
(2, 2, 2, '2026-09-05', '2026-09-07'),
(3, 3, 3, '2026-09-10', '2026-09-12'),
(4, 3, 3, '2026-09-10', '2026-09-12'),
(5, 3, 3, '2026-09-10', '2026-09-12');

--
-- Triggers `rentals`
--
DELIMITER $$
CREATE TRIGGER `AfterRentalReturn` AFTER UPDATE ON `rentals` FOR EACH ROW BEGIN
    IF NEW.ReturnDate IS NOT NULL THEN
        UPDATE Vehicles
        SET Status = 'Available'
        WHERE VehicleID = NEW.VehicleID;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `VehicleID` int(11) NOT NULL,
  `VehicleNumber` varchar(20) NOT NULL,
  `Model` varchar(50) NOT NULL,
  `DailyRate` decimal(10,2) NOT NULL CHECK (`DailyRate` > 0),
  `Status` varchar(20) DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`VehicleID`, `VehicleNumber`, `Model`, `DailyRate`, `Status`) VALUES
(1, 'ABC-123', 'Toyota Corolla', 5000.00, 'Available'),
(2, 'XYZ-456', 'Honda Civic', 6000.00, 'Available'),
(3, 'LMN-789', 'Suzuki Alto', 3000.00, 'Rented');

-- --------------------------------------------------------

--
-- Structure for view `rentalreport`
--
DROP TABLE IF EXISTS `rentalreport`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `rentalreport`  AS SELECT `c`.`Name` AS `Name`, `c`.`Phone` AS `Phone`, `v`.`VehicleNumber` AS `VehicleNumber`, `v`.`Model` AS `Model`, `r`.`RentalDate` AS `RentalDate`, `r`.`ReturnDate` AS `ReturnDate`, `p`.`Amount` AS `Amount` FROM (((`rentals` `r` join `customers` `c` on(`r`.`CustomerID` = `c`.`CustomerID`)) join `vehicles` `v` on(`r`.`VehicleID` = `v`.`VehicleID`)) left join `payments` `p` on(`r`.`RentalID` = `p`.`RentalID`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerID`),
  ADD UNIQUE KEY `Phone` (`Phone`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `RentalID` (`RentalID`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`RentalID`),
  ADD KEY `idx_customer` (`CustomerID`),
  ADD KEY `idx_vehicle` (`VehicleID`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`VehicleID`),
  ADD UNIQUE KEY `VehicleNumber` (`VehicleNumber`),
  ADD KEY `idx_status` (`Status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rentals`
--
ALTER TABLE `rentals`
  MODIFY `RentalID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `VehicleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`RentalID`) REFERENCES `rentals` (`RentalID`);

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerID`),
  ADD CONSTRAINT `rentals_ibfk_2` FOREIGN KEY (`VehicleID`) REFERENCES `vehicles` (`VehicleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
